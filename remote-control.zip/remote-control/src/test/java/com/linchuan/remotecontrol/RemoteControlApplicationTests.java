package com.linchuan.remotecontrol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RemoteControlApplicationTests {

	@Test
	void contextLoads() {
	}

}
