package com.linchuan.remotecontrol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RemoteControlApplication {

	public static void main(String[] args) {
		SpringApplication.run(RemoteControlApplication.class, args);
	}

}
